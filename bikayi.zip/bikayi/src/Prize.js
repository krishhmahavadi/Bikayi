import React, { useState } from 'react'

const Prize=()=> {
    const[value,setValue]=useState()


    try {
        const response = fetch(`http://api.nobelprize.org/v1/prize.json`)
        .then(response => response.json())
        .then(jsondata => console.log(jsondata))
        console.log("fetch get method called")

       
      } catch (err) {
        console.error(err.message);
      }

   


  return (
    <div>
      Hello this is prize component





      
    </div>
  )
}

export default Prize
