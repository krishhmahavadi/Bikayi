import logo from './logo.svg';
import './App.css';
import Prize from './Prize';
import PrizeCopy from './Prizecopy';

function App() {
  return (
    <div className="App">
     {/* <h1>hello world</h1> */}
     {/* <Prize/> */}
     <PrizeCopy/>
    </div>
  );
}

export default App;
