import React, { useState,useEffect } from 'react'

const PrizeCopy=()=> {
    const[value,setValue]=useState([])

const feData=async()=>{
    try {
        const response = await fetch("http://api.nobelprize.org/v1/prize.json");
        const jsonData = await response.json();
        console.log(jsonData)
        const  val=jsonData.prizes
        setValue(val)

       
      } catch (err) {
        console.error(err.message);
      }
    }

    useEffect(() => {
      feData();
    }, []);
console.log(value)

  return (
    <div>
      Hello this is prize component
<hr>
</hr>

  
    <label for="cars">Choose a year:</label><select name="cars" id="cars">
    {value.map((row) => (  <option value="volvo">{row.year}</option>
   ))}
  </select>
  
  <label for="cars">Choose a category :</label><select name="cars" id="cars">
    {value.map((row) => (  <option value="volvo">{row.category}</option>
   ))}
  </select>
 
  {/* <label for="cars">Choose a car:</label><select name="cars" id="cars">
    {value.map((row) => (  <option value="volvo">{row.laureates}</option>
   ))}
  </select> */}
    
    </div>
  )
}

export default PrizeCopy
